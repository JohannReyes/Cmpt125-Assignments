#ifndef A1_Q4_H
#define A1_Q4_H

//takes in a cstring (i.e., a character array that has a \0 character as the
// last element) that represents a mathematics operation (+, -, or *).
//Returns the result as an int.
int performMathOp(char* operation);

#endif
