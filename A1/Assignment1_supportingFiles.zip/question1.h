#ifndef A1_Q1_H
#define A1_Q1_H

//interlaces a positive 4-digit int between 1000 and 9999
// with another positive 5-digit int between 10000 and 99999
//returns the result as a positive 9-digit int.
unsigned int interlace_ints(unsigned int firstNum, unsigned int secondNum);

#endif
