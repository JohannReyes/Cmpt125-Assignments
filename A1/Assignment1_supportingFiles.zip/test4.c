#include <stdio.h>
#include "question4.h"

int main() {
  printf("%d\n", performMathOp("12+345"));
  printf("%d\n", performMathOp("0-4"));
  printf("%d\n", performMathOp("13*13"));

  return 0;
}
