#ifndef A2_Q1_H
#define A2_Q1_H

//a recursive function that expands a positive int by adding 0’s between the
// digits and returns the result as a positive int.
//If the input int has only one digit, return the input directly.
unsigned int expand_int(unsigned int number);

#endif
