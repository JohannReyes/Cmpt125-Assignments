#include <stdio.h>
#include <stdlib.h>
#include "question4.h"

//a helper function to print the content in the array
//assumes stringArray is not NULL
void printStringArray(char* stringArray[], unsigned int size) {
  for (int i=0; i<size; i++) {
    printf("%s\n", stringArray[i]);
  }
}

int main() {

  //ask the user for the number of words


  //process input, handle cases like input being 0 and malloc failure

  return 0;
}
